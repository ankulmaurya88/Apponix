const Activity=document.querySelectorAll('div')

const Student_name=document.querySelector('.student')

// Select different elements

const onfield_Game=document.querySelector('.activity-2')

// Display selected information
console.log(onfind_Game)


// Highlight selected card
const cloub_person=document.querySelector('.activity-3')